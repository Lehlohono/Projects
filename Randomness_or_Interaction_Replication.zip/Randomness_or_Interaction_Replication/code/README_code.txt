Run reproduce_all.py to regenerate data and figures. It requires numpy, pandas, matplotlib, scipy, statsmodels, and yfinance.
