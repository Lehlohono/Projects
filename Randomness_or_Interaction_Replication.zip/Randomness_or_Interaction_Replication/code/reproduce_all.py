
"""
Replication script for:
Randomness or Interaction? Testing EMH, Ising, and Lux-Marchesi Models Against Financial Market Stylized Facts

This script downloads S&P 500 data, computes returns, simulates the EMH, Ising,
and simplified Lux-Marchesi models, then saves generated data and figures.

Install dependencies if needed:
    pip install numpy pandas matplotlib scipy statsmodels yfinance
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf
from scipy.stats import skew, kurtosis, jarque_bera
from statsmodels.tsa.stattools import acf

os.makedirs("data", exist_ok=True)
os.makedirs("figures", exist_ok=True)

np.random.seed(42)
T_TARGET = 6288

# -----------------------------
# Helper functions
# -----------------------------
def savefig(name):
    plt.tight_layout()
    plt.savefig(os.path.join("figures", name), dpi=300, bbox_inches="tight")
    plt.close()


def stats_dict(x):
    jb, p = jarque_bera(x)
    return {
        "mean": np.mean(x),
        "std": np.std(x),
        "skewness": skew(x),
        "kurtosis": kurtosis(x, fisher=False),
        "jb_stat": jb,
        "jb_p": p,
    }

# -----------------------------
# 1. S&P 500 empirical benchmark
# -----------------------------
sp500 = yf.download("^GSPC", start="2000-01-01", end="2025-01-01", auto_adjust=True)
sp500["returns"] = np.log(sp500["Close"] / sp500["Close"].shift(1))
sp500 = sp500.dropna()
returns_real = sp500["returns"].to_numpy()
T = len(returns_real)

sp500.to_csv("data/sp500_data_with_returns.csv")
pd.DataFrame({"returns_real": returns_real}).to_csv("data/returns_real.csv", index=False)

plt.figure(figsize=(10, 5))
plt.plot(sp500.index, sp500["Close"])
plt.title("S&P 500 Index")
plt.xlabel("Date")
plt.ylabel("Price")
plt.grid(True)
savefig("fig1_sp500_index.png")

plt.figure(figsize=(10, 5))
plt.plot(sp500.index, returns_real)
plt.title("S&P 500 Log Returns")
plt.xlabel("Date")
plt.ylabel("Return")
plt.grid(True)
savefig("fig2_sp500_returns.png")

plt.figure(figsize=(8, 5))
plt.hist(returns_real, bins=100, density=True)
plt.title("Distribution of S&P 500 Returns")
plt.xlabel("Return")
plt.ylabel("Density")
savefig("fig3_sp500_distribution.png")

plt.figure(figsize=(8, 5))
plt.plot(acf(returns_real, nlags=50), label="Returns")
plt.plot(acf(np.abs(returns_real), nlags=50), label="Absolute Returns")
plt.title("Autocorrelation")
plt.xlabel("Lag")
plt.ylabel("Autocorrelation")
plt.legend()
savefig("fig4_sp500_acf.png")

# -----------------------------
# 2. EMH Gaussian random walk
# -----------------------------
mu = np.mean(returns_real)
sigma = np.std(returns_real)
returns_emh = np.random.normal(mu, sigma, T)
prices_emh = 100 * np.exp(np.cumsum(returns_emh))
pd.DataFrame({"return_emh": returns_emh, "price_emh": prices_emh}).to_csv("data/emh_generated_data.csv", index=False)

plt.figure(figsize=(10, 5))
plt.plot(prices_emh)
plt.title("EMH Random Walk Price Simulation")
plt.xlabel("Time")
plt.ylabel("Price")
plt.grid(True)
savefig("fig5_emh_price.png")

plt.figure(figsize=(8, 5))
plt.hist(returns_emh, bins=100, density=True)
plt.title("Distribution of EMH Returns")
plt.xlabel("Return")
plt.ylabel("Density")
savefig("fig6_emh_distribution.png")

plt.figure(figsize=(8, 5))
plt.plot(acf(returns_emh, nlags=50), label="Returns")
plt.plot(acf(np.abs(returns_emh), nlags=50), label="Absolute Returns")
plt.title("EMH Autocorrelation")
plt.xlabel("Lag")
plt.ylabel("Autocorrelation")
plt.legend()
savefig("fig7_emh_acf.png")

# -----------------------------
# 3. Ising market model
# -----------------------------
L = 40
J = 1.0
lambda_price = 0.10
noise_sigma = 0.002

def metropolis_step(spins, beta, J):
    N = spins.shape[0]
    for _ in range(N*N):
        i = np.random.randint(0, N)
        j = np.random.randint(0, N)
        s = spins[i, j]
        neighbours = (
            spins[(i+1)%N, j] + spins[(i-1)%N, j]
            + spins[i, (j+1)%N] + spins[i, (j-1)%N]
        )
        dE = 2 * J * s * neighbours
        if dE < 0 or np.random.rand() < np.exp(-beta*dE):
            spins[i, j] *= -1
    return spins

def simulate_ising(beta):
    spins = np.random.choice([-1, 1], size=(L, L))
    returns = []
    prev_M = np.mean(spins)
    for _ in range(T):
        spins = metropolis_step(spins, beta, J)
        M = np.mean(spins)
        r = lambda_price * (M - prev_M) + np.random.normal(0, noise_sigma)
        returns.append(r)
        prev_M = M
    returns = np.array(returns)
    prices = 100 * np.exp(np.cumsum(returns))
    return returns, prices

ising_outputs = {}
for label, beta in [("disordered", 0.20), ("critical", 0.44), ("ordered", 0.70)]:
    r, p = simulate_ising(beta)
    ising_outputs[label] = (r, p)
    pd.DataFrame({f"return_ising_{label}": r, f"price_ising_{label}": p}).to_csv(f"data/ising_{label}_generated_data.csv", index=False)

plt.figure(figsize=(12, 5))
for label, (r, p) in ising_outputs.items():
    plt.plot(p, label=label.capitalize())
plt.title("Ising Market Regimes")
plt.xlabel("Time")
plt.ylabel("Price")
plt.legend()
plt.grid(True)
savefig("fig8_ising_regimes.png")

plt.figure(figsize=(8, 5))
for label, (r, p) in ising_outputs.items():
    plt.plot(acf(np.abs(r), nlags=50), label=label.capitalize())
plt.title("Absolute Return ACF")
plt.xlabel("Lag")
plt.ylabel("Autocorrelation")
plt.legend()
savefig("fig9_ising_acf.png")

# -----------------------------
# 4. Simplified Lux-Marchesi model
# -----------------------------
np.random.seed(42)
P0 = 100
Pf = 100
N_total = 1000
Nf = 500
Nc = 500
beta_switch = 0.1
sigma_noise = 0.005
prices = [P0]
returns_lm = []

for t in range(1, T):
    P = prices[-1]
    trend = 0 if t <= 1 else prices[-1] - prices[-2]
    Df = Nf * (Pf - P)
    Dc = Nc * trend
    r = 0.00001 * (Df + Dc) + np.random.normal(0, sigma_noise)
    P_new = P * np.exp(r)
    prices.append(P_new)
    returns_lm.append(r)
    profit_f = abs(Pf - P)
    profit_c = abs(trend)
    switch = beta_switch * (profit_c - profit_f)
    Nf = int(np.clip(Nf - switch, 100, 900))
    Nc = N_total - Nf

prices_lm = np.array(prices)
returns_lm = np.array(returns_lm)
pd.DataFrame({"return_lux_marchesi": returns_lm, "price_lux_marchesi": prices_lm[1:]}).to_csv("data/lux_marchesi_generated_data.csv", index=False)

plt.figure(figsize=(10, 5))
plt.plot(prices_lm)
plt.title("Lux-Marchesi Market")
plt.xlabel("Time")
plt.ylabel("Price")
plt.grid(True)
savefig("fig10_lux_price.png")

plt.figure(figsize=(8, 5))
plt.plot(acf(np.abs(returns_lm), nlags=50))
plt.title("Lux-Marchesi Absolute Return ACF")
plt.xlabel("Lag")
plt.ylabel("Autocorrelation")
savefig("fig11_lux_acf.png")

# -----------------------------
# 5. Summary statistics
# -----------------------------
summary = []
summary.append({"dataset": "S&P 500", **stats_dict(returns_real)})
summary.append({"dataset": "EMH", **stats_dict(returns_emh)})
for label, (r, p) in ising_outputs.items():
    summary.append({"dataset": f"Ising {label}", **stats_dict(r)})
summary.append({"dataset": "Lux-Marchesi", **stats_dict(returns_lm)})

pd.DataFrame(summary).to_csv("data/simulation_and_empirical_summary_statistics.csv", index=False)
print(pd.DataFrame(summary))
